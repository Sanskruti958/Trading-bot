# Binance Futures Testnet Trading Bot

A clean, production-style Python CLI for placing orders on the **Binance Futures Testnet (USDT-M)**. Built with a layered architecture — separate client, domain logic, validation, and CLI — plus structured logging and thorough error handling.

---

## Table of Contents

- [Features](#features)
- [Project Structure](#project-structure)
- [Setup](#setup)
- [Configuration](#configuration)
- [Usage](#usage)
- [Logging](#logging)
- [Error Handling](#error-handling)
- [Assumptions](#assumptions)

---

## Features

| Feature | Detail |
|---|---|
| Order types | MARKET, LIMIT, STOP_MARKET (bonus) |
| Sides | BUY, SELL |
| CLI | `argparse` with subcommands, typed flags, and clear help text |
| Validation | Symbol, side, type, quantity, price, stop-price — all validated before any API call |
| Logging | Dual handlers: timestamped file (`DEBUG`) + console (`INFO`) |
| Error handling | Separate cases for validation errors, Binance API errors, and network failures |
| Extra commands | `account` (balance viewer) and `open-orders` (list open positions) |

---

## Project Structure

```
trading_bot/
├── bot/
│   ├── __init__.py
│   ├── client.py          # BinanceClient — HTTP, signing, raw API calls
│   ├── orders.py          # OrderManager, OrderRequest, OrderResult
│   ├── validators.py      # Input validation (raises ValueError on failure)
│   └── logging_config.py  # Shared logger factory
├── cli.py                 # CLI entry point (argparse subcommands)
├── logs/                  # Auto-created; one .log file per calendar day
├── .env.example           # Environment variable template
├── requirements.txt
└── README.md
```

---

## Setup

### 1. Get Testnet Credentials

1. Go to [https://testnet.binancefuture.com](https://testnet.binancefuture.com)
2. Log in (or register) and navigate to **API Management**
3. Generate a new API key pair
4. Note your **API Key** and **Secret Key**

### 2. Clone / Download

```bash
git clone <repo-url>
cd trading_bot
```

### 3. Create a Virtual Environment

```bash
python3 -m venv .venv
source .venv/bin/activate      # macOS/Linux
.venv\Scripts\activate         # Windows
```

### 4. Install Dependencies

```bash
pip install -r requirements.txt
```

### 5. Configure Credentials

```bash
cp .env.example .env
# Edit .env and paste your API key and secret
```

Your `.env` should look like:

```
BINANCE_API_KEY=your_key_here
BINANCE_API_SECRET=your_secret_here
BINANCE_BASE_URL=https://testnet.binancefuture.com
```

---

## Configuration

All configuration is via environment variables (or a `.env` file):

| Variable | Required | Default | Description |
|---|---|---|---|
| `BINANCE_API_KEY` | ✅ | — | Your testnet API key |
| `BINANCE_API_SECRET` | ✅ | — | Your testnet API secret |
| `BINANCE_BASE_URL` | ❌ | `https://testnet.binancefuture.com` | Override to point at a different endpoint |

---

## Usage

### General help

```bash
python cli.py --help
python cli.py place-order --help
```

---

### Place a MARKET order

```bash
# Buy 0.001 BTC at market price
python cli.py place-order \
    --symbol BTCUSDT \
    --side BUY \
    --type MARKET \
    --quantity 0.001
```

Example output:

```
┌─ Order Request ─────────────────────────────
│  Symbol     : BTCUSDT
│  Side       : BUY
│  Type       : MARKET
│  Quantity   : 0.001
└─────────────────────────────────────────────

┌─ Order Response ────────────────────────────
│  Order ID    : 3865241
│  Symbol      : BTCUSDT
│  Side        : BUY
│  Type        : MARKET
│  Status      : FILLED
│  Orig Qty    : 0.001
│  Executed Qty: 0.001
│  Avg Price   : 67432.10
│  Price       : 0
└─────────────────────────────────────────────

✅  Order placed! ID: 3865241  Status: FILLED
```

---

### Place a LIMIT order

```bash
# Sell 0.001 BTC at $70,000 (resting order, GTC)
python cli.py place-order \
    --symbol BTCUSDT \
    --side SELL \
    --type LIMIT \
    --quantity 0.001 \
    --price 70000
```

---

### Place a STOP_MARKET order (bonus order type)

```bash
# Protective stop: sell 0.001 BTC if price drops to $65,000
python cli.py place-order \
    --symbol BTCUSDT \
    --side SELL \
    --type STOP_MARKET \
    --quantity 0.001 \
    --stop-price 65000
```

---

### View account balances

```bash
python cli.py account
```

---

### List open orders

```bash
# All symbols
python cli.py open-orders

# Specific symbol
python cli.py open-orders --symbol BTCUSDT
```

---

## Logging

Logs are written to `logs/trading_bot_YYYYMMDD.log` (one file per day).

- **File handler**: `DEBUG` level — includes every request (without signature), raw response body (truncated to 500 chars), and all info/error messages.
- **Console handler**: `INFO` level — clean, actionable messages only.

Sample log lines are included in `logs/trading_bot_20250601.log`.

---

## Error Handling

| Scenario | Behaviour |
|---|---|
| Invalid CLI input (bad side, zero qty, missing price) | Prints `❌ Validation error: …` and exits with code 1 |
| Binance API error (e.g., insufficient margin, bad symbol) | Prints `❌ API error <code>: <message>` and exits with code 1 |
| Network / timeout failure | Propagates `requests.RequestException`; logged + clean failure message |
| Missing API credentials | Detected at startup; prints clear message and exits |

---

## Assumptions

1. **Hedge mode is NOT assumed** — all orders use `positionSide=BOTH` (one-way mode), which is the testnet default.
2. **Quantity precision** — the user is responsible for providing a quantity that satisfies the symbol's `LOT_SIZE` filter. The bot does not auto-round, to avoid silent order modification.
3. **Time-in-force** — defaults to `GTC` for LIMIT orders; can be overridden with `--time-in-force IOC|FOK`.
4. **No persistence** — the bot is stateless; it does not track order history between runs.
5. **Python 3.9+** is required (uses `from __future__ import annotations`).
