"""
Order placement logic for Binance Futures Testnet.
Translates validated domain objects into API calls and formats responses.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from decimal import Decimal
from typing import Any, Dict, Optional

from bot.client import BinanceClient, BinanceAPIError
from bot.logging_config import setup_logger

logger = setup_logger()


# ---------------------------------------------------------------------------
# Domain dataclasses
# ---------------------------------------------------------------------------


@dataclass
class OrderRequest:
    """Validated, typed representation of an order to be placed."""

    symbol: str
    side: str                      # BUY | SELL
    order_type: str                # MARKET | LIMIT | STOP_MARKET
    quantity: Decimal
    price: Optional[Decimal] = None
    stop_price: Optional[Decimal] = None
    time_in_force: str = "GTC"     # Relevant for LIMIT orders

    def summary(self) -> str:
        lines = [
            "┌─ Order Request ─────────────────────────────",
            f"│  Symbol     : {self.symbol}",
            f"│  Side       : {self.side}",
            f"│  Type       : {self.order_type}",
            f"│  Quantity   : {self.quantity}",
        ]
        if self.price is not None:
            lines.append(f"│  Price      : {self.price}")
        if self.stop_price is not None:
            lines.append(f"│  Stop Price : {self.stop_price}")
        if self.order_type == "LIMIT":
            lines.append(f"│  TIF        : {self.time_in_force}")
        lines.append("└─────────────────────────────────────────────")
        return "\n".join(lines)


@dataclass
class OrderResult:
    """Parsed, human-friendly view of the Binance order response."""

    order_id: int
    symbol: str
    side: str
    order_type: str
    status: str
    orig_qty: str
    executed_qty: str
    avg_price: str
    price: str
    raw: Dict[str, Any] = field(repr=False)

    @classmethod
    def from_response(cls, data: Dict[str, Any]) -> "OrderResult":
        return cls(
            order_id=data.get("orderId", 0),
            symbol=data.get("symbol", ""),
            side=data.get("side", ""),
            order_type=data.get("type", ""),
            status=data.get("status", ""),
            orig_qty=data.get("origQty", "0"),
            executed_qty=data.get("executedQty", "0"),
            avg_price=data.get("avgPrice", "0"),
            price=data.get("price", "0"),
            raw=data,
        )

    def summary(self) -> str:
        lines = [
            "┌─ Order Response ────────────────────────────",
            f"│  Order ID    : {self.order_id}",
            f"│  Symbol      : {self.symbol}",
            f"│  Side        : {self.side}",
            f"│  Type        : {self.order_type}",
            f"│  Status      : {self.status}",
            f"│  Orig Qty    : {self.orig_qty}",
            f"│  Executed Qty: {self.executed_qty}",
            f"│  Avg Price   : {self.avg_price}",
            f"│  Price       : {self.price}",
            "└─────────────────────────────────────────────",
        ]
        return "\n".join(lines)


# ---------------------------------------------------------------------------
# Order placement
# ---------------------------------------------------------------------------


class OrderManager:
    """High-level order operations using a BinanceClient."""

    def __init__(self, client: BinanceClient) -> None:
        self.client = client

    def place_order(self, req: OrderRequest) -> OrderResult:
        """
        Place an order on Binance Futures Testnet.

        Args:
            req: Validated OrderRequest.

        Returns:
            OrderResult parsed from the API response.

        Raises:
            BinanceAPIError: On API rejection.
            requests.RequestException: On network failure.
        """
        logger.info(
            "Placing %s %s order | symbol=%s qty=%s price=%s",
            req.side, req.order_type, req.symbol, req.quantity, req.price,
        )

        params: Dict[str, Any] = {
            "symbol": req.symbol,
            "side": req.side,
            "type": req.order_type,
            "quantity": str(req.quantity),
        }

        if req.order_type == "LIMIT":
            params["timeInForce"] = req.time_in_force
            params["price"] = str(req.price)

        if req.order_type == "STOP_MARKET":
            params["stopPrice"] = str(req.stop_price)

        try:
            response = self.client.new_order(**params)
        except BinanceAPIError as exc:
            logger.error("Order rejected by Binance: %s", exc)
            raise
        except Exception as exc:
            logger.error("Unexpected error placing order: %s", exc)
            raise

        result = OrderResult.from_response(response)
        logger.info(
            "Order placed successfully | orderId=%s status=%s executedQty=%s avgPrice=%s",
            result.order_id, result.status, result.executed_qty, result.avg_price,
        )
        return result
