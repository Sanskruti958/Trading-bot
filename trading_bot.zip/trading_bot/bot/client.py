"""
Low-level Binance Futures Testnet client.
Handles request signing, HTTP communication, and raw error surfacing.
"""

from __future__ import annotations

import hashlib
import hmac
import time
from typing import Any, Dict, Optional
from urllib.parse import urlencode

import requests

from bot.logging_config import setup_logger

TESTNET_BASE_URL = "https://testnet.binancefuture.com"

logger = setup_logger()


class BinanceAPIError(Exception):
    """Raised when the Binance API returns a non-2xx response or an error payload."""

    def __init__(self, code: int, message: str) -> None:
        self.code = code
        self.message = message
        super().__init__(f"Binance API error {code}: {message}")


class BinanceClient:
    """
    Thin wrapper around the Binance Futures Testnet REST API.
    Handles HMAC-SHA256 request signing and structured logging.
    """

    def __init__(self, api_key: str, api_secret: str, base_url: str = TESTNET_BASE_URL) -> None:
        self.api_key = api_key
        self.api_secret = api_secret
        self.base_url = base_url.rstrip("/")
        self.session = requests.Session()
        self.session.headers.update(
            {
                "X-MBX-APIKEY": self.api_key,
                "Content-Type": "application/x-www-form-urlencoded",
            }
        )
        logger.debug("BinanceClient initialised. Base URL: %s", self.base_url)

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _sign(self, params: Dict[str, Any]) -> str:
        """Return HMAC-SHA256 hex signature for the given query string."""
        query_string = urlencode(params)
        return hmac.new(
            self.api_secret.encode("utf-8"),
            query_string.encode("utf-8"),
            hashlib.sha256,
        ).hexdigest()

    def _timestamp(self) -> int:
        return int(time.time() * 1000)

    def _request(
        self,
        method: str,
        endpoint: str,
        params: Optional[Dict[str, Any]] = None,
        signed: bool = True,
    ) -> Dict[str, Any]:
        """
        Make an HTTP request, optionally signing it.

        Args:
            method: HTTP verb (GET, POST, DELETE).
            endpoint: API path, e.g. '/fapi/v1/order'.
            params: Query / body parameters.
            signed: Whether to add timestamp + signature.

        Returns:
            Parsed JSON response dict.

        Raises:
            BinanceAPIError: On API-level error (code field in response).
            requests.RequestException: On network/transport failure.
        """
        params = params or {}
        if signed:
            params["timestamp"] = self._timestamp()
            params["signature"] = self._sign(params)

        url = f"{self.base_url}{endpoint}"
        logger.debug("→ %s %s | params: %s", method.upper(), url, {k: v for k, v in params.items() if k != "signature"})

        try:
            if method.upper() in ("GET", "DELETE"):
                response = self.session.request(method, url, params=params, timeout=10)
            else:
                response = self.session.request(method, url, data=params, timeout=10)
        except requests.RequestException as exc:
            logger.error("Network error contacting Binance: %s", exc)
            raise

        logger.debug("← HTTP %s | body: %s", response.status_code, response.text[:500])

        data = response.json()

        # Binance surfaces errors with a 'code' key (negative int) even on 200 sometimes
        if isinstance(data, dict) and "code" in data and data["code"] != 200:
            raise BinanceAPIError(data["code"], data.get("msg", "Unknown error"))

        if not response.ok:
            raise BinanceAPIError(response.status_code, response.text)

        return data

    # ------------------------------------------------------------------
    # Public API methods
    # ------------------------------------------------------------------

    def get_exchange_info(self) -> Dict[str, Any]:
        """Fetch exchange information (symbols, filters, etc.)."""
        return self._request("GET", "/fapi/v1/exchangeInfo", signed=False)

    def get_account(self) -> Dict[str, Any]:
        """Fetch account information including balances."""
        return self._request("GET", "/fapi/v2/account")

    def new_order(self, **kwargs: Any) -> Dict[str, Any]:
        """
        Place a new futures order.
        Accepts any valid Binance Futures order parameters as keyword arguments.
        """
        return self._request("POST", "/fapi/v1/order", params=kwargs)

    def cancel_order(self, symbol: str, order_id: int) -> Dict[str, Any]:
        """Cancel an open order by orderId."""
        return self._request("DELETE", "/fapi/v1/order", params={"symbol": symbol, "orderId": order_id})

    def get_open_orders(self, symbol: Optional[str] = None) -> Any:
        """Fetch all open orders, optionally filtered by symbol."""
        params: Dict[str, Any] = {}
        if symbol:
            params["symbol"] = symbol
        return self._request("GET", "/fapi/v1/openOrders", params=params)
