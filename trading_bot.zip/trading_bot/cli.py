"""
CLI entry point for the Binance Futures Testnet trading bot.

Usage examples:
    python cli.py place-order --symbol BTCUSDT --side BUY --type MARKET --quantity 0.001
    python cli.py place-order --symbol BTCUSDT --side SELL --type LIMIT --quantity 0.001 --price 60000
    python cli.py place-order --symbol BTCUSDT --side SELL --type STOP_MARKET --quantity 0.001 --stop-price 58000
    python cli.py account
    python cli.py open-orders --symbol BTCUSDT
"""

from __future__ import annotations

import argparse
import os
import sys
from typing import Optional

from dotenv import load_dotenv

from bot.client import BinanceAPIError, BinanceClient
from bot.logging_config import setup_logger
from bot.orders import OrderManager, OrderRequest
from bot.validators import (
    validate_order_type,
    validate_price,
    validate_quantity,
    validate_side,
    validate_stop_price,
    validate_symbol,
)

load_dotenv()
logger = setup_logger()


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def get_client() -> BinanceClient:
    """Build BinanceClient from environment variables."""
    api_key = os.getenv("BINANCE_API_KEY", "").strip()
    api_secret = os.getenv("BINANCE_API_SECRET", "").strip()
    base_url = os.getenv("BINANCE_BASE_URL", "https://testnet.binancefuture.com").strip()

    if not api_key or not api_secret:
        print("❌  BINANCE_API_KEY and BINANCE_API_SECRET must be set (env vars or .env file).")
        logger.error("Missing API credentials in environment.")
        sys.exit(1)

    return BinanceClient(api_key=api_key, api_secret=api_secret, base_url=base_url)


def _print_success(msg: str) -> None:
    print(f"\n✅  {msg}\n")


def _print_failure(msg: str) -> None:
    print(f"\n❌  {msg}\n")


# ---------------------------------------------------------------------------
# Command handlers
# ---------------------------------------------------------------------------


def cmd_place_order(args: argparse.Namespace) -> None:
    """Validate input, build an OrderRequest, and place it."""
    try:
        symbol = validate_symbol(args.symbol)
        side = validate_side(args.side)
        order_type = validate_order_type(args.type)
        quantity = validate_quantity(args.quantity)
        price = validate_price(args.price, order_type)
        stop_price = validate_stop_price(args.stop_price, order_type)
    except ValueError as exc:
        _print_failure(f"Validation error: {exc}")
        logger.warning("Input validation failed: %s", exc)
        sys.exit(1)

    req = OrderRequest(
        symbol=symbol,
        side=side,
        order_type=order_type,
        quantity=quantity,
        price=price,
        stop_price=stop_price,
        time_in_force=args.time_in_force.upper(),
    )

    print(req.summary())

    client = get_client()
    manager = OrderManager(client)

    try:
        result = manager.place_order(req)
    except BinanceAPIError as exc:
        _print_failure(f"API error {exc.code}: {exc.message}")
        sys.exit(1)
    except Exception as exc:
        _print_failure(f"Unexpected error: {exc}")
        logger.exception("Unhandled exception in place_order")
        sys.exit(1)

    print(result.summary())
    _print_success(f"Order placed! ID: {result.order_id}  Status: {result.status}")


def cmd_account(args: argparse.Namespace) -> None:
    """Print account balances."""
    client = get_client()
    try:
        account = client.get_account()
    except BinanceAPIError as exc:
        _print_failure(f"API error {exc.code}: {exc.message}")
        sys.exit(1)

    assets = [a for a in account.get("assets", []) if float(a.get("walletBalance", 0)) > 0]
    print("\n┌─ Account Balances ──────────────────────────")
    for asset in assets:
        print(f"│  {asset['asset']:<8}  wallet: {asset['walletBalance']:>18}  unrealisedPnL: {asset.get('unrealizedProfit', '0'):>18}")
    print("└─────────────────────────────────────────────\n")


def cmd_open_orders(args: argparse.Namespace) -> None:
    """List open orders, optionally filtered by symbol."""
    client = get_client()
    symbol: Optional[str] = None
    if args.symbol:
        try:
            symbol = validate_symbol(args.symbol)
        except ValueError as exc:
            _print_failure(str(exc))
            sys.exit(1)
    try:
        orders = client.get_open_orders(symbol=symbol)
    except BinanceAPIError as exc:
        _print_failure(f"API error {exc.code}: {exc.message}")
        sys.exit(1)

    if not orders:
        print("\nNo open orders found.\n")
        return

    print(f"\nOpen orders ({len(orders)}):")
    for o in orders:
        print(
            f"  ID={o['orderId']}  {o['symbol']}  {o['side']}  {o['type']}"
            f"  qty={o['origQty']}  price={o['price']}  status={o['status']}"
        )
    print()


# ---------------------------------------------------------------------------
# Argument parser
# ---------------------------------------------------------------------------


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="trading_bot",
        description="Binance Futures Testnet trading bot",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=__doc__,
    )
    subparsers = parser.add_subparsers(dest="command", required=True)

    # -- place-order --
    po = subparsers.add_parser("place-order", help="Place a new futures order")
    po.add_argument("--symbol", required=True, help="Trading pair, e.g. BTCUSDT")
    po.add_argument("--side", required=True, choices=["BUY", "SELL", "buy", "sell"],
                    help="Order side: BUY or SELL")
    po.add_argument("--type", required=True,
                    choices=["MARKET", "LIMIT", "STOP_MARKET", "market", "limit", "stop_market"],
                    help="Order type: MARKET, LIMIT, or STOP_MARKET")
    po.add_argument("--quantity", required=True, type=float, help="Order quantity (base asset)")
    po.add_argument("--price", type=float, default=None, help="Limit price (required for LIMIT)")
    po.add_argument("--stop-price", type=float, default=None,
                    help="Stop trigger price (required for STOP_MARKET)")
    po.add_argument("--time-in-force", default="GTC",
                    choices=["GTC", "IOC", "FOK", "gtc", "ioc", "fok"],
                    help="Time-in-force for LIMIT orders (default: GTC)")
    po.set_defaults(func=cmd_place_order)

    # -- account --
    acc = subparsers.add_parser("account", help="Show account balances")
    acc.set_defaults(func=cmd_account)

    # -- open-orders --
    oo = subparsers.add_parser("open-orders", help="List open orders")
    oo.add_argument("--symbol", default=None, help="Filter by symbol (optional)")
    oo.set_defaults(func=cmd_open_orders)

    return parser


def main() -> None:
    parser = build_parser()
    args = parser.parse_args()
    logger.debug("Command received: %s | args: %s", args.command, vars(args))
    args.func(args)


if __name__ == "__main__":
    main()
